package com.example.lastversion

data class TaskData(
    val TaskName:String,
    val TaskDescription:String
)
